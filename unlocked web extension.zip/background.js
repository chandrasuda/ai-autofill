chrome.runtime.onMessage.addListener(async (request, sender, sendResponse) => {
  if (request.action === 'getAnswer') {
    const documentFiles = await chrome.storage.local.get('documentFiles');
    const documentContents = documentFiles.documentFiles.map((file) => file.contents).join('\n');
    const answer = await callAIModel(request.question, documentContents);
    sendResponse({ answer });
  }
});

async function callAIModel(question, documentContents) {
  const modelPath = chrome.runtime.getURL('model/model.bin');
  const model = await loadModel(modelPath);
  const answer = await getAnswerFromModel(model, question, documentContents);
  return answer;
}

async function loadModel(modelPath) {
  // Loads model code here
}

async function getAnswerFromModel(model, question, documentContents) {
  // Use RAG technique to get answer from model using question and documentContents
}