document.getElementById('uploadButton').addEventListener('click', async () => {
  const fileInput = document.getElementById('fileInput');
  const files = fileInput.files;
  for (const file of files) {
    const fileReader = new FileReader();
    fileReader.onload = async () => {
      const fileContents = fileReader.result;
      const existingFiles = await chrome.storage.local.get('documentFiles');
      const newFiles = existingFiles.documentFiles || [];
      newFiles.push({ name: file.name, contents: fileContents });
      await chrome.storage.local.set({ documentFiles: newFiles });
      updateFileList();
    };
    fileReader.readAsText(file);
  }
});

document.getElementById('clearButton').addEventListener('click', async () => {
  await chrome.storage.local.remove('documentFiles');
  updateFileList();
});

async function updateFileList() {
  const fileList = document.getElementById('fileList');
  fileList.innerHTML = '';
  const documentFiles = await chrome.storage.local.get('documentFiles');
  if (documentFiles.documentFiles) {
    for (const file of documentFiles.documentFiles) {
      const li = document.createElement('li');
      li.textContent = file.name;
      fileList.appendChild(li);
    }
  }
}

updateFileList();