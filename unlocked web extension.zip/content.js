async function answerQuestion(question) {
  const response = await chrome.runtime.sendMessage({ action: 'getAnswer', question });
  return response.answer;
}

document.addEventListener('click', async (event) => {
  const target = event.target;
  if (target.tagName.toLowerCase() === 'input' || target.tagName.toLowerCase() === 'textarea') {
    const answer = await answerQuestion(target.placeholder || target.title);
    target.value = answer;
  }
});

document.addEventListener('keyup', async (event) => {
  const target = event.target;
  if (target.tagName.toLowerCase() === 'input' || target.tagName.toLowerCase() === 'textarea') {
    const question = target.value.trim();
    if (question) {
      const answer = await answerQuestion(question);
      target.value = answer;
    }
  }
});